from django.apps import AppConfig
"""
la classe CurriculatorappConfig estende AppConfig ed ha 2 parametri: un default_auto_field settato su BigAutoField ed un nome che è quello dell'app
"""

class CurriculatorappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CurriculatorApp'
