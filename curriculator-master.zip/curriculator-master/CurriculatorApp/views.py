import re
from itertools import chain
import yaml
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import get_template
from django.urls import reverse_lazy
from django.views.generic import DetailView, TemplateView
from xhtml2pdf import pisa
from yaml.scanner import ScannerError
from .forms import *
from django.contrib import messages
from django.views.generic.edit import CreateView
from django.contrib.auth import authenticate, login
from .models import *


def register(request):
    """
    View per la registrazione di un nuovo Utente. Fornisce la visualizzazione del Template.

    **Template:**

    :template:`registration/registration.html`
    """
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            u_name = form.cleaned_data.get('username')
            pwd = form.cleaned_data.get('password1')
            user = authenticate(username=u_name, first_name=first_name, last_name=last_name, password=pwd)
            login(request, user)
            messages.success(request, 'Account creato correttamente')
            return redirect('homepage')
    else:
        form = UserRegisterForm()
    return render(request, 'registration/registration.html', {'user_form': form})


class Profilo(DetailView):
    """
    View per la visualizzazione del profilo e relativi dati.

    **Model:**

    :model:`CurriculatorApp.Profile`

    **Template:**

    :template:`profile/profilo_view.html`
    """
    template_name = 'profile/profilo_view.html'
    model = Profile

    def get_context_data(self, **kwargs):
        """
        Inserisce nel context tutti i Curriculum associati a quel Profilo specifico.
        """
        context = super(Profilo, self).get_context_data(**kwargs)
        context['curriculum'] = Curriculum.objects.filter(profilo=kwargs['object'].id)
        return context


class ProfileUpdateView(LoginRequiredMixin, TemplateView):
    """
    View per la modifica del profilo tramite un apposito form.
    Permette di modificare o aggiungere i dati mancanti per il completamento.

    **Template**

    :template:`profile/aggiorna-profilo.html`

    """
    profile_form = ProfiloForm
    template_name = 'profile/aggiorna-profilo.html'

    def post(self, request):
        """
        la funzione post assegna a alla variabile 'post_data' i dati inseriti dall'utente e alla variabile 'file_data' i file caricati
        se non vi sono dati oppure file, alle variabili viene assegnato None
        se i dati sono validi il profilo viene salvato correttamente
        'redirect' reindirizza l'utente verso l'URL generato da 'reverse'
        la funzione ritorna una pagina http attraverso il rendering di context
        """
        post_data = request.POST or None
        file_data = request.FILES or None

        profile_form = ProfiloForm(post_data, file_data, instance=request.user.profile)

        if profile_form.is_valid():
            profile_form.save()
            messages.success(request, 'Il tuo profilo è stato aggiornato correttamente!')
            return redirect(reverse('CurriculatorApp:profilo', kwargs={'pk': self.request.user.pk}))

        context = self.get_context_data(profile_form=profile_form)

        return self.render_to_response(context)

    def get(self, request, *args, **kwargs):
        return self.post(request, *args, **kwargs)


def new_cv(request):
    """
    Metodo per la creazione di un'istanza di Curriculum all'interno del Profilo.
    """
    profilo = Profile.objects.get(user=request.user)
    data_creazione = datetime.date.today()
    data_modifica = datetime.date.today()
    cv = Curriculum.objects.create(profilo=profilo, data_creazione=data_creazione, data_modifica=data_modifica)
    cv.save()
    return redirect(request.META['HTTP_REFERER'])


class CurriclumCreate(CreateView):
    model = Curriculum
    fields = []
    template_name = 'profile/create-curriculum.html'

    def get_initial(self):
        """
        questo metodo ha lo scopo di fornire i dati iniziali quando creiamo un curriculum
        il parametro 'initial' conterrà, per copia, il valore del suo omonimo chiamato sulla classe genitore CurriclumCreate
        la funzione ritornerà poi tale paramentro
        """
        initial = super(CurriclumCreate, self).get_initial()
        initial = initial.copy()
        profile = get_object_or_404(Profile, user=self.request.user)
        date_creation = datetime.date.today()
        date_modifica = datetime.date.today()
        initial['profilo'] = profile
        initial['data_creazione'] = date_creation
        initial['data_modifica'] = date_modifica
        return initial

    def form_valid(self, form):
        """
        'form.istance' serve per assegnare alla variabile 'profilo' il profilo dell'utente corrente recuperato con 'self.request.user.profile'
        """
        form.instance.profilo = self.request.user.profile
        return super(CurriclumCreate, self).form_valid(form)

    def get_success_url(self):
        """
        in 'profile_id' viene memorizzata la primary key dell'user
        come con il metodo 'render' anche 'reverse_lazy' restituisce un URL, in questo caso per la vista 'profilo',
        la particolarità di tale funzione, però, è che l'URL non sarà generato finché non sarà necessario
        """
        profile_id = self.request.user.pk
        return reverse_lazy('CurriculatorApp:profilo', kwargs={'pk': profile_id})

def curriculum_delete(request, pk):
    """
    in tale funzione viene sviluppato il codice per l'eliminazione di una sezione dal curriculum
    """
    curriculum = Curriculum.objects.get(id=pk)
    curriculum.delete()
    messages.error(request, 'Sezione eliminata con successo!')
    return redirect(request.META['HTTP_REFERER'])

class CurriculumDetail(DetailView):
    """
    in questa classe andiamo a definire la vista 'get_context_data' per l'aggiunta  di paramentri al dizionario 'context'
    in questo caso viene chiamato il metodo 'super' per far riferimento al dizionario della classe genitore
    le chiavi 'form_elemento', 'form_sezione', 'curriculum', 'sezioni', 'elementi' vengono così aggiunte al dizionario con i rispettivi valori
    """
    model = Curriculum
    template_name = 'profile/curriculum-detail.html'

    def get_context_data(self, **kwargs):
        context = super(CurriculumDetail, self).get_context_data(**kwargs)
        context['form_elemento'] = ElementForm()
        context['form_sezione'] = SectionForm()
        context['curriculum'] = kwargs['object']
        context['sezioni'] = Sezione.objects.filter(curriculum=kwargs['object'].id)
        context['elementi'] = Elemento.objects.filter(sezione__in=context['sezioni'])
        return context

class CVTemplatePdf(DetailView):
    """
    come per la funzione 'CurriculumDetail' con l'aggiunta di una printf dell'attributo 'profilo'
    """
    model = Curriculum
    template_name = 'profile/template-pdf.html'

    def get_context_data(self, **kwargs):
        context = super(CVTemplatePdf, self).get_context_data(**kwargs)
        context['form_elemento'] = ElementForm()
        context['form_sezione'] = SectionForm()
        context['curriculum'] = kwargs['object']
        context['sezioni'] = Sezione.objects.filter(curriculum=kwargs['object'].id)
        print(kwargs['object'].profilo)
        context['elementi'] = Elemento.objects.filter(sezione__in=context['sezioni'])
        return context

def delete_elemento(request, pk):
    """
    la funzione 'delete_elemento' serve ad eliminare un elemento dalla sezione
    """
    elemento = Elemento.objects.get(id=pk)
    cv = Curriculum.objects.get(id=elemento.sezione.curriculum.id)
    cv.data_modifica = datetime.date.today()
    cv.save()
    elemento.delete()
    messages.error(request, 'Elemento eliminato con successo!')
    return redirect(request.META['HTTP_REFERER'])

def delete_sezione(request, pk):
    """
    la funzione 'delete_sezione' serve ad eliminare una sezione del curriculum
    """
    sezione = Sezione.objects.get(id=pk)
    cv = Curriculum.objects.get(id=sezione.curriculum.id)
    cv.data_modifica = datetime.date.today()
    cv.save()
    sezione.delete()
    messages.error(request, 'Sezione eliminata con successo!')
    #refresh della pagina corrente
    return redirect(request.META['HTTP_REFERER'])

def elemento_create(request):
    """
    tale funzione serve per gestire la creazione di un elemento
    'elemento_create' verifica se il parametro 'request' sia un ajax e, in caso affermativo, crea un nuovo oggetto 'elemento' con  con il valore di request
    l funzione 'yaml.load' ritorna errore nel caso in cui vi sia un errore sintattico, altrimenti crea un nuovo elemento e lo salva nel DB
    il campo 'data_modifica' dell'oggetto 'Curriculum' ad esso associato viene aggiiornato alla data odierna ed entrambi gli oggetti vengono caricati sul DB
    infine l'utente viene rediretto alla pagina 'HTTP_REFERER'
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        elemento_titolo = request.POST['titolo']
        elemento_data_inizio = request.POST['data_inizio']
        if elemento_data_inizio == '':
            elemento_data_inizio = None
        elemento_data_fine = request.POST['data_fine']
        if elemento_data_fine == '':
            elemento_data_fine = None
        elemento_sezione = Sezione.objects.get(id=request.POST['sezione'])
        elemento_campi = request.POST['campi']
        try:
            campi = yaml.load(elemento_campi, yaml.SafeLoader)
        except ScannerError as exc:
            messages.error(request, 'Sintassi invalida nei campi dell\'elemento.')
            return JsonResponse({'error': True, 'message': 'Sintassi Invalida'})
        else:
            if elemento_titolo and elemento_campi and elemento_sezione:
                elemento = Elemento.objects.create(titolo=elemento_titolo, data_inizio=elemento_data_inizio,
                                               data_fine=elemento_data_fine, sezione=elemento_sezione,
                                               campi=yaml.safe_load(elemento_campi))
                cv = elemento_sezione.curriculum
                cv.data_modifica = datetime.date.today()
                cv.save()
                elemento.save()
                return redirect(request.META['HTTP_REFERER'])


def element_update(request):
    """
    situazione analoga alla funzione 'elemento_create', ma in questo caso l'obiettivo diventa l'update dell'elemento sul DB
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        elemento = Elemento.objects.get(id=request.POST['id_elemento'])
        elemento.titolo = request.POST['titolo']
        elemento.data_inizio = request.POST['data_inizio']
        if elemento.data_inizio == '':
            elemento.data_inizio = None
        elemento.data_fine = request.POST['data_fine']
        if elemento.data_fine == '':
            elemento.data_fine = None
        elemento.campi = request.POST['campi']
        try:
            campi = yaml.load(elemento.campi, yaml.SafeLoader)
        except ScannerError as exc:
            messages.error(request, 'Sintassi invalida nei campi dell\'elemento.')
            return JsonResponse({'error': True, 'message': 'Sintassi Invalida'})
        else:
            elemento.sezione = Sezione.objects.get(id=request.POST['sezione'])
            if elemento.titolo and elemento.campi and elemento.sezione:
                cv = elemento.sezione.curriculum
                cv.data_modifica = datetime.date.today()
                cv.save()
                elemento.save()
                return redirect(request.META['HTTP_REFERER'])

def sezione_create(request):
    """
    come per 'elemento_create', ma riguardo le sezioni
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        sezione_titolo = request.POST['titolo']
        sezione_curriculum = Curriculum.objects.get(pk=request.POST['curriculum'])
        if sezione_titolo:
            sezione = Sezione.objects.create(titolo=sezione_titolo, curriculum=sezione_curriculum)
            sezione.save()
            sezione_curriculum.data_modifica = datetime.date.today()
            sezione_curriculum.save()
            return redirect(request.META['HTTP_REFERER'])

def sezione_update(request):
    """
    come per 'element_update', ma riguardo le sezioni
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        sezione = Sezione.objects.get(id=request.POST['id_sezione'])
        sezione.titolo = request.POST['titolo']
        cv = Curriculum.objects.get(pk=sezione.curriculum.id)
        if sezione.titolo:
            sezione.save()
            cv.data_modifica = datetime.date.today()
            cv.save()
            return redirect(request.META['HTTP_REFERER'])

def sort(request):
    """
    'sort' verifica se 'request' sia una reuqest ajax oppure no
    se si, recupra l'oggetto 'sezione' dal DB e setta a true il paramemtro ordinamento_manuale, salvandolo
    dopodiché prende una lista di ID e la riordina in base alla posizione che occupano nella lista
    la loro posizione viene, poi, salvata sul DB
    La funzione ritorna una risposta http con messaggio di 'successo'
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        sezione = Sezione.objects.get(id=request.POST['sezione_id'])
        sezione.ordinamento_manuale = True
        sezione.save()
        list_id = [int(s) for s in re.findall(r'\b\d+\b', request.POST['ordine'])]
        lista_ordine = []
        for index, id_elemento in enumerate(list_id):
            elemento = Elemento.objects.get(pk=id_elemento)
            elemento.posizione = index
            elemento.save()
        return HttpResponse('successo')

def sort_manual(request):
    """
    tale funzione si occupa di ordinare il set di oggetti 'elemento' sulla base dei campi 'data_fine' e 'data_inizio' in ordine discendente
    unisce poi i due queryset in un'unica lista di primary keys degli oggetti, nell'ordine desiderato
    infine la fuznione itera sulla lista appena creata, caricando la nuova 'posizione' di ogni oggetto
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        elementi = Elemento.objects.filter(sezione=Sezione.objects.get(id=request.POST['id']))
        elementi_no_data_fine = elementi.filter(data_fine=None)
        elementi_no_data_fine = elementi_no_data_fine.order_by('-data_inizio')
        list_no_data_fine = elementi_no_data_fine.values_list('pk', flat=True)
        elementi_terminati = elementi.exclude(data_fine=None)
        elementi_terminati = elementi_terminati.order_by('-data_fine', '-data_inizio')
        list_terminati = elementi_terminati.values_list('pk', flat=True)
        queryset_finale = list(chain(list_no_data_fine, list_terminati))
        for index, id_elemento in enumerate(queryset_finale):
            elemento = Elemento.objects.get(pk=id_elemento)
            elemento.posizione = index
            elemento.save()
    return HttpResponse('successo')


def set_manual(request):
    """
    serve ad attivare/disattivare il campo 'ordinamento_manuale' di una sezione
    la funzione recupera l'oggetto 'sezione' dal DB usando l'ID
    se il paramentro 'ordinamento_manuale' era settato a True lo porta a False e vice versa
    poi salva l'oggetto nel DB
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        is_ajax = True
    else:
        is_ajax = False

    if is_ajax:
        sezione = Sezione.objects.get(id=request.POST['id'])
        if not sezione.ordinamento_manuale:
            sezione.ordinamento_manuale = True
        else:
            sezione.ordinamento_manuale = False

        sezione.save()
    return HttpResponse('ok')

def pdf_report_create(request, cv_id):
    """
    questa funzione genera una versione pdf per un dato oggetto 'Curriculum'
    accetta come parametri una richiesta http e l'ID del curriculum e restituisce un oggetto risposta
    dall'ID viene recuperato l'oggetto curriculum, con tutte le sue sezioni ed i suoi elementi
    viene creato un dizionario con tali oggetti, il quale viene passato al file 'profile/pdfreport.html' necessario per realizzare una rappresentazione html del report
    la funzione crea, quindi, una risposta http con opzione 'attachment; filename="cv_report.pdf"' per suggerire al browser di scaricare il pdf e non visualizzarlo in una finestra di browser
    grazie alla libreria 'Pisa' converte il documento in formato PDF e lo scrive nell'oggetto risposta
    in caso di errore restituisce un messaggio di notifica http
    """
    cv = Curriculum.objects.get(id=cv_id)
    sezioni = Sezione.objects.filter(curriculum=cv.id)
    elementi = Elemento.objects.filter(sezione__in=sezioni)
    template_path = "profile/pdfreport.html"

    context = {
        'object': cv,
        'sezioni': sezioni,
        'elementi': elementi,
    }

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="cv_report.pdf"'

    template = get_template(template_path)

    html = template.render(context)
    pisa_status = pisa.CreatePDF(html, dest=response)

    if pisa_status.err:
        return HttpResponse('Errore <pre>' + html + '</pre>')
    return response
