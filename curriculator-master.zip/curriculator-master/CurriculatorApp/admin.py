from django.contrib import admin
from .models import *
"""
qui vengono riportati i modelli per i quali l'amministratore può gestire accessi e permessi
"""

admin.site.register(Profile)
admin.site.register(Curriculum)
admin.site.register(Sezione)
admin.site.register(Elemento)
