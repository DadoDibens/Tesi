from django.views.generic import TemplateView, CreateView
from CurriculatorApp.models import Profile


class Homepage(TemplateView):
    """
    homepage rappresenta la classe con cui l'utente si interfaccerà dopo aver effettuato la registrazione
    la funzione get_context_data inserisce, all'interno del dizionario context il profilo dell'utente registrato. In fase di log-in verranno mostrati i dati del profilo dell'utente nella homepage
    """
    template_name = 'Curriculator/home.html'


def get_context_data(self, **kwargs):
        if self.request.user.is_authenticated:
            context = super(Homepage, self).get_context_data(**kwargs)
            profilo = Profile.objects.get(user=self.request.user)
            context['utente'] = profilo
            return context
